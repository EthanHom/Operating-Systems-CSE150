package nachos.threads;

import nachos.machine.*;

/**
 * A KThread is a thread that can be used to execute Nachos kernel code.
 * Nachos allows multiple threads to run concurrently.
 */
public class KThread implements Comparable<KThread> {
    /**
     * Get the current thread.
     *
     * @return the current thread.
     */
    public static KThread currentThread() {
        Lib.assertTrue(currentThread != null);
        return currentThread;
    }

    /**
     * Allocate a new <tt>KThread</tt>. If this is the first <tt>KThread</tt>,
     * create an idle thread as well.
     */
    public KThread() {
        if (currentThread != null) {
            tcb = new TCB();
            // Create a queue to hold any threads that might join on this thread
            joinQueue = ThreadedKernel.scheduler.newThreadQueue(false);
        } else {
            readyQueue = ThreadedKernel.scheduler.newThreadQueue(false);
            readyQueue.acquire(this);

            currentThread = this;
            tcb = TCB.currentTCB();
            name = "main";
            restoreState();

            createIdleThread();
        }
    }

    /**
     * Allocate a new KThread.
     *
     * @param target the object whose <tt>run</tt> method is called.
     */
    public KThread(Runnable target) {
        this();
        this.target = target;
    }

    /**
     * Set the target of this thread.
     *
     * @param target the object whose <tt>run</tt> method is called.
     * @return this thread.
     */
    public KThread setTarget(Runnable target) {
        Lib.assertTrue(status == statusNew);
        this.target = target;
        return this;
    }

    /**
     * Set the name of this thread. This name is used for debugging purposes
     * only.
     *
     * @param name the name to give to this thread.
     * @return this thread.
     */
    public KThread setName(String name) {
        this.name = name;
        return this;
    }

    /**
     * Get the name of this thread. This name is used for debugging purposes
     * only.
     *
     * @return the name given to this thread.
     */
    public String getName() {
        return name;
    }

    /**
     * Get the full name of this thread. This includes its name along with its
     * numerical ID. This name is used for debugging purposes only.
     *
     * @return the full name given to this thread.
     */
    public String toString() {
        return (name + " (#" + id + ")");
    }

    /**
     * Deterministically and consistently compare this thread to another thread.
     */
    @Override
    public int compareTo(KThread thread) {
        if (id < thread.id)
            return -1;
        else if (id > thread.id)
            return 1;
        else
            return 0;
    }

    /**
     * Causes this thread to begin execution. The result is that two threads are
     * running concurrently: the current thread (which returns from the call to
     * the <tt>fork</tt> method) and the other thread (which executes its
     * target's <tt>run</tt> method).
     */
    public void fork() {
        Lib.assertTrue(status == statusNew);
        Lib.assertTrue(target != null);

        Lib.debug(dbgThread, "Forking thread: " + toString()
                                + " Runnable: " + target);

        boolean intStatus = Machine.interrupt().disable();

        tcb.start(new Runnable() {
            public void run() {
                runThread();
            }
        });

        ready();
        Machine.interrupt().restore(intStatus);
    }

    private void runThread() {
        begin();
        target.run();
        finish();
    }

    private void begin() {
        Lib.debug(dbgThread, "Beginning thread: " + toString());
        Lib.assertTrue(this == currentThread);

        restoreState();
        Machine.interrupt().enable();
    }

    /**
     * Finish the current thread and schedule it to be destroyed when it is safe
     * to do so.
     */
    public static void finish() {
        Lib.debug(dbgThread, "Finishing thread: " + currentThread.toString());
        Machine.interrupt().disable();

        Machine.autoGrader().finishingCurrentThread();
        Lib.assertTrue(toBeDestroyed == null);
        toBeDestroyed = currentThread;

        // Wake any thread that joined on us
        if (currentThread.joinQueue != null) {
            KThread joiner = currentThread.joinQueue.nextThread();
            if (joiner != null) {
                joiner.ready();
            }
        }

        currentThread.status = statusFinished;
        sleep(); // never returns
    }

    /**
     * Relinquish the CPU if any other thread is ready to run.
     * If so, put the current thread on the ready queue, so that it
     * will eventually be rescheduled.
     */
    public static void yield() {
        Lib.debug(dbgThread, "Yielding thread: " + currentThread.toString());
        Lib.assertTrue(currentThread.status == statusRunning);

        boolean intStatus = Machine.interrupt().disable();
        currentThread.ready();
        runNextThread();
        Machine.interrupt().restore(intStatus);
    }

    /**
     * Relinquish the CPU because the current thread is either finished
     * or blocked. This thread must be the current thread.
     */
    public static void sleep() {
        Lib.debug(dbgThread, "Sleeping thread: " + currentThread.toString());
        Lib.assertTrue(Machine.interrupt().disabled());

        if (currentThread.status != statusFinished) {
            currentThread.status = statusBlocked;
        }
        runNextThread();
    }

    /**
     * Moves this thread to the ready state and adds it to the scheduler's
     * ready queue.
     */
    public void ready() {
        Lib.debug(dbgThread, "Ready thread: " + toString());

        Lib.assertTrue(Machine.interrupt().disabled());
        Lib.assertTrue(status != statusReady);

        status = statusReady;
        if (this != idleThread) {
            readyQueue.waitForAccess(this);
        }

        Machine.autoGrader().readyThread(this);
    }

    /**
     * Waits for this thread to finish. If this thread is already finished,
     * returns immediately. This method must only be called once. The second call
     * is not guaranteed to return. This thread must not be the current thread.
     */
    public void join() {
        Lib.debug(dbgThread, "Joining to thread: " + toString());
        Lib.assertTrue(this != currentThread);

        boolean intStatus = Machine.interrupt().disable();

        // If we've already been joined, that's an error
        Lib.assertTrue(!this.hasBeenJoined,
            "ERROR: This thread has already been joined once!");

        this.hasBeenJoined = true;

        if (this.status != statusFinished) {
            // Put the joiner in our join queue
            this.joinQueue.waitForAccess(currentThread());
            KThread.sleep();
        }

        Machine.interrupt().restore(intStatus);
    }

    /**
     * Create the idle thread. Whenever there are no threads ready to be run,
     * and <tt>runNextThread()</tt> is called, it will run the idle thread.
     */
    private static void createIdleThread() {
        Lib.assertTrue(idleThread == null);

        idleThread = new KThread(new Runnable() {
            public void run() {
                while (true) {
                    KThread.yield();
                }
            }
        });
        idleThread.setName("idle");

        Machine.autoGrader().setIdleThread(idleThread);
        idleThread.fork();
    }

    /**
     * Determine the next thread to run, then dispatch the CPU to that thread
     * using <tt>run()</tt>.
     */
    private static void runNextThread() {
        KThread nextThread = readyQueue.nextThread();
        if (nextThread == null) {
            nextThread = idleThread;
        }
        nextThread.run();
    }

    /**
     * Dispatch the CPU to this thread.
     */
    private void run() {
        Lib.assertTrue(Machine.interrupt().disabled());
        Machine.yield();

        currentThread.saveState();

        Lib.debug(dbgThread, "Switching from: " + currentThread.toString()
                + " to: " + toString());

        currentThread = this;
        tcb.contextSwitch();
        currentThread.restoreState();
    }

    /**
     * Prepare this thread to be run.
     */
    protected void restoreState() {
        Lib.debug(dbgThread, "Running thread: " + currentThread.toString());

        Lib.assertTrue(Machine.interrupt().disabled());
        Lib.assertTrue(this == currentThread);
        Lib.assertTrue(tcb == TCB.currentTCB());

        Machine.autoGrader().runningThread(this);
        status = statusRunning;

        if (toBeDestroyed != null) {
            toBeDestroyed.tcb.destroy();
            toBeDestroyed.tcb = null;
            toBeDestroyed = null;
        }
    }

    /**
     * Prepare this thread to give up the processor.
     */
    protected void saveState() {
        Lib.assertTrue(Machine.interrupt().disabled());
        Lib.assertTrue(this == currentThread);
    }

    // ------------------------------------------------------------------------
    //  Basic test classes & your join tests
    // ------------------------------------------------------------------------

    /**
     * A simple test runner that prints loop messages.
     */
    private static class PingTest implements Runnable {
        PingTest(int which) {
            this.which = which;
        }

        public void run() {
            for (int i = 0; i < 5; i++) {
                System.out.println("*** thread " + which + " looped " + i + " times");
                currentThread.yield();
            }
        }
        private int which;
    }

    /**
     * joinTest1:
     * Child finishes before parent calls join on it.
     */
    private static void joinTest1() {
        System.out.println("\n-- joinTest1: child finishes before parent calls join --");
        KThread child1 = new KThread(new Runnable() {
            public void run() {
                System.out.println("I (heart) Nachos!");
            }
        }).setName("child1");

        child1.fork();

        // Let the child finish
        for (int i = 0; i < 5; i++) {
            System.out.println("busy...");
            KThread.currentThread().yield();
        }

        child1.join();
        System.out.println("After joining, child1 should be finished.");
        System.out.println("is it? " + (child1.status == statusFinished));
        Lib.assertTrue((child1.status == statusFinished),
                       "Expected child1 to be finished.");
    }

    /**
     * joinTest2:
     *  - One thread forks another, they both run PingTest.
     *  - Then the parent calls join() on the child, waiting for it to finish
     *  - We previously tried to join again (which is not allowed),
     *    so that line is now commented out to avoid error.
     */
    private static class PingTest2 implements Runnable {
        PingTest2(int which) {
            this.which = which;
        }

        public void run() {
            for (int i = 0; i < 5; i++) {
                System.out.println("*** thread " + which + " looped " + i + " times");
                currentThread.yield();
            }
        }
        private int which;
    }

    private static void joinTest2() {
        System.out.println("\n-- joinTest2: Fork a PingTest thread, run parent's PingTest, then join --");

        KThread th1 = new KThread(new PingTest2(1)).setName("forked thread 1");
        th1.fork();

        // current thread also runs a ping test
        new PingTest2(0).run();

        // now join on th1
        th1.join();

        // second join is not allowed (Nachos instructions)
        // so we comment it out:
        // th1.join();  // would cause assertion error
    }

    public static void selfTest() {
        Lib.debug(dbgThread, "Enter KThread.selfTest");

        // Basic test from skeleton
        new KThread(new PingTest(10)).setName("forked thread").fork();
        new PingTest(11).run();

        joinTest1();
        joinTest2();

        System.out.println("\n-- KThread.selfTest() complete --");
    }

    // ------------------------------------------------------------------------
    //  Internal fields
    // ------------------------------------------------------------------------
    private static final char dbgThread = 't';
    public Object schedulingState = null;  // Additional state for schedulers

    private static final int statusNew      = 0;
    private static final int statusReady    = 1;
    private static final int statusRunning  = 2;
    private static final int statusBlocked  = 3;
    private static final int statusFinished = 4;

    private int status = statusNew;
    private String name = "(unnamed thread)";
    private Runnable target;
    private TCB tcb;

    /** Unique identifier for this thread. Used to deterministically compare threads. */
    private int id = numCreated++;
    private static int numCreated = 0;

    /** The queue of threads waiting to join on this thread. */
    private ThreadQueue joinQueue = null;

    /** Flag: has this thread been joined already? (Only once allowed.) */
    private boolean hasBeenJoined = false;

    /** Shared data structures for the entire system of threads. */
    private static ThreadQueue readyQueue = null;
    private static KThread currentThread = null;
    private static KThread toBeDestroyed = null;
    private static KThread idleThread = null;
}
