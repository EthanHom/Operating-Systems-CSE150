package nachos.threads;

import nachos.ag.BoatGrader;

/**
 * Uses the boat to move a number of adults and children from Oahu to Molokai.
 *
 * The boat can carry either one adult or two children.
 * Children are used to shuttle the boat back and forth.
 *
 * This solution uses a Lock and a single Condition2 to coordinate actions.
 * Global counters track the number of adults and children on each island and
 * a Boolean flag tracks the boat’s location.
 *
 * NOTE: Do not remove any comments.
 */
public class Boat {
    static BoatGrader bg;
    
    // Global state variables:
    static int adultsOnOahu;
    static int childrenOnOahu;
    static int adultsOnMolokai;
    static int childrenOnMolokai;
    static boolean boatOnOahu; // true if boat is on Oahu; false if on Molokai
    static boolean finished;
    
    // Use Nachos provided synchronization primitives.
    static Lock lock = new Lock();
    static Condition2 condition = new Condition2(lock);
    
    public static void selfTest() {
        BoatGrader b = new BoatGrader();
    
        System.out.println("\n ***Testing Boats with only 2 children***");
        begin(0, 2, b);
    
        System.out.println("\n ***Testing Boats with 2 children, 1 adult***");
        begin(1, 2, b);
    
        System.out.println("\n ***Testing Boats with 3 children, 3 adults***");
        begin(3, 3, b);
        
        System.out.println("\n ***Testing Boats with only 100 children***");
        begin(0, 100, b);
    
        System.out.println("\n ***Testing Boats with 2 children, 100 adults***");
        begin(100, 2, b);
        
        System.out.println("\n ***Testing Boats with 3 children, 1 adult***");
        begin(1, 3, b);
        
        System.out.println("\n ***Testing Boats with 0 children, 0 adults***");
        begin(0, 0, b);
    }
    
    // The begin method initializes the global state and creates a KThread for each person.
    public static void begin(int adults, int children, BoatGrader b) {
        bg = b;
    
        // If there are no people, mark finished immediately.
        if (adults == 0 && children == 0) {
            finished = true;
            return;
        }
    
        // Initialize global state.
        adultsOnOahu = adults;
        childrenOnOahu = children;
        adultsOnMolokai = 0;
        childrenOnMolokai = 0;
        boatOnOahu = true;
        finished = false;
    
        // Create adult threads.
        for (int i = 0; i < adults; i++) {
            KThread t = new KThread(new Runnable() {
                public void run() {
                    AdultItinerary();
                }
            });
            t.setName("Adult");
            t.fork();
        }
    
        // Create child threads.
        for (int i = 0; i < children; i++) {
            KThread t = new KThread(new Runnable() {
                public void run() {
                    ChildItinerary();
                }
            });
            t.setName("Child");
            t.fork();
        }
    
        // Main thread yields until finished becomes true.
        while (!finished) {
            KThread.yield();
        }
    }
    
    // ------------------------------------------------------------------------
    // AdultItinerary: What an adult does.
    // An adult waits until the boat is on Oahu and the children are not busy ferrying.
    // Then the adult rows alone from Oahu to Molokai.
    // ------------------------------------------------------------------------
    static void AdultItinerary() {
        lock.acquire();
        // Wait until the boat is on Oahu and (if there are at least two children waiting,
        // then children should ferry first).
        while (!boatOnOahu || childrenOnOahu >= 2) {
            condition.sleep();
        }
        // Adult crosses from Oahu to Molokai.
        boatOnOahu = false;
        bg.AdultRowToMolokai();
        adultsOnOahu--;
        adultsOnMolokai++;
        condition.wakeAll();
        lock.release();
    }
    
    // ------------------------------------------------------------------------
    // ChildItinerary: What a child does.
    // Child threads repeatedly check the state and perform actions based on:
    //  - Ferry cycle (if there are adults waiting and at least 2 children on Oahu)
    //  - Rowing back from Molokai when the boat is on Molokai and some children remain on Oahu
    //  - Final crossing when no adults remain.
    // ------------------------------------------------------------------------
    static void ChildItinerary() {
        lock.acquire();
        while (!finished) {
            // Branch 1: Ferry cycle when at least one adult is waiting and at least 2 children are on Oahu.
            if (adultsOnOahu > 0 && boatOnOahu && childrenOnOahu >= 2) {
                boatOnOahu = false;
                bg.ChildRowToMolokai();    // Pilot child rows.
                bg.ChildRideToMolokai();   // Passenger child rides.
                childrenOnOahu -= 2;
                childrenOnMolokai += 2;
                // Step 2: One child returns from Molokai to Oahu if there are still adults waiting.
                if (adultsOnOahu > 0) {
                    boatOnOahu = true;
                    bg.ChildRowToOahu(); // A child rows back.
                    childrenOnMolokai--;
                    childrenOnOahu++;
                }
                condition.wakeAll();
            }
            // Branch 2: If the boat is on Molokai and there are children on Molokai while some children remain on Oahu,
            // have a child row back to Oahu (regardless of adult count).
            else if (!boatOnOahu && childrenOnMolokai > 0 && childrenOnOahu > 0) {
                boatOnOahu = true;
                bg.ChildRowToOahu();
                childrenOnMolokai--;
                childrenOnOahu++;
                condition.wakeAll();
            }
            // Branch 3: Final crossing: when no adults remain on Oahu.
            else if (adultsOnOahu == 0 && boatOnOahu && childrenOnOahu > 0) {
                if (childrenOnOahu >= 2) {
                    boatOnOahu = false;
                    bg.ChildRowToMolokai();
                    bg.ChildRideToMolokai();
                    childrenOnOahu -= 2;
                    childrenOnMolokai += 2;
                } else { // Only one child remains.
                    boatOnOahu = false;
                    bg.ChildRowToMolokai();
                    childrenOnOahu--;
                    childrenOnMolokai++;
                }
                finished = true;
                condition.wakeAll();
            }
            else {
                condition.sleep();
            }
        }
        lock.release();
    }
    
    // ------------------------------------------------------------------------
    // SampleItinerary remains unchanged for demonstration purposes.
    // Do not modify SampleItinerary.
    // ------------------------------------------------------------------------
    static void SampleItinerary() {
        System.out.println("\n ***Everyone piles on the boat and goes to Molokai***");
        bg.AdultRowToMolokai();
        bg.ChildRideToMolokai();
        bg.AdultRideToMolokai();
        bg.ChildRideToMolokai();
    }
}
