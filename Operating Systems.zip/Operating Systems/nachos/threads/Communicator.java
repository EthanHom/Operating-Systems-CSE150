package nachos.threads;

import nachos.machine.*;

/**
 * A <i>communicator</i> allows threads to synchronously exchange 32-bit
 * messages. Multiple threads can be waiting to <i>speak</i>, and multiple
 * threads can be waiting to <i>listen</i>. But there should never be a time
 * when both a speaker and a listener are waiting, because the two threads can
 * be paired off at this point.
 */
public class Communicator {
    private Lock lock;

    // We will maintain two condition variables: one for speakers, one for listeners.
    // Also, we'll keep a "hasMessage" to indicate if there's a message in flight,
    // plus counters for how many speakers/listeners are waiting.
    private Condition2 speakerCondition;
    private Condition2 listenerCondition;

    // shared state:
    private boolean hasMessage;      // true if there's a word in flight
    private int word;               // the actual message buffer

    private int waitingSpeakers;    // how many speakers are currently waiting
    private int waitingListeners;   // how many listeners are currently waiting

    /**
     * Allocate a new communicator.
     */
    public Communicator() {
        lock = new Lock();
        speakerCondition = new Condition2(lock);
        listenerCondition = new Condition2(lock);
        hasMessage = false;
        word = 0;
        waitingSpeakers = 0;
        waitingListeners = 0;
    }

    /**
     * Wait for a thread to listen through this communicator, and then transfer
     * <i>word</i> to the listener. Does not return until this thread is paired
     * up with a listening thread. Exactly one listener should receive <i>word</i>.
     *
     * This implementation handles multiple speakers and multiple listeners by
     * using counters to track how many are waiting and a 'hasMessage' to indicate
     * a message is in flight.
     *
     * @param word the integer to transfer.
     */
    public void speak(int word) {
        lock.acquire();

        // If there's already a message in flight, or no listeners to receive it,
        // then we have to wait until conditions change.
        // Typically you wait if (hasMessage == true).
        while (hasMessage) {
            waitingSpeakers++;
            speakerCondition.sleep();
            waitingSpeakers--;
        }

        // Now we can place our message
        this.word = word;
        hasMessage = true;

        // If any listeners are waiting, let exactly one proceed
        if (waitingListeners > 0) {
            listenerCondition.wake();
        }

        // Next: we wait until the listener has consumed the message (hasMessage == false)
        while (hasMessage) {
            waitingSpeakers++;
            speakerCondition.sleep();
            waitingSpeakers--;
        }
        System.out.println("Exiting speak() with no leftover conditions");
        lock.release();
    }

    /**
     * Wait for a thread to speak through this communicator, and then return the
     * <i>word</i> that thread passed to <tt>speak()</tt>.
     */
    public int listen() {
        lock.acquire();

        // If there's no message yet, wait.
        while (!hasMessage) {
            waitingListeners++;
            listenerCondition.sleep();
            waitingListeners--;
        }

        // Retrieve the message.
        int messageToReturn = this.word;
        
        // Clear the message so future speakers can proceed.
        hasMessage = false;
        
        // Wake all waiting speakers so that one of them can now proceed.
        speakerCondition.wakeAll();
        
        System.out.println("Exiting listen() with no leftover conditions");
        lock.release();
        return messageToReturn;
    }


    // ------------------------------------------------------------------------
    // Everything below this line is the same test code you had before.
    // We do NOT remove or alter your tests: commTest1..commTest6, snippet tests, etc.
    // Just ensure they eventually finish without deadlock.
    // ------------------------------------------------------------------------

    /**
     * Test 1: 1 listener, then 1 speaker
     */
    public static void commTest1() {
        System.out.println("\n-- commTest1: 1 listener, then 1 speaker --");
        final Communicator c = new Communicator();

        KThread listener = new KThread(new Runnable() {
            public void run() {
                System.out.println("Listener thread started, about to listen...");
                int val = c.listen();
                System.out.println("Listener thread received word: " + val);
            }
        }).setName("Listener1");

        KThread speaker = new KThread(new Runnable() {
            public void run() {
                KThread.yield();
                System.out.println("Speaker thread started, about to speak(111)...");
                c.speak(111);
                System.out.println("Speaker thread done speaking(111).");
            }
        }).setName("Speaker1");

        listener.fork();
        speaker.fork();
        listener.join();
        speaker.join();
    }

    /**
     * Test 2: 1 speaker, then 1 listener
     */
    public static void commTest2() {
        System.out.println("\n-- commTest2: 1 speaker, then 1 listener --");
        final Communicator c = new Communicator();

        KThread speaker = new KThread(new Runnable() {
            public void run() {
                System.out.println("Speaker thread started, about to speak(222)...");
                c.speak(222);
                System.out.println("Speaker thread done speaking(222).");
            }
        }).setName("Speaker2");

        KThread listener = new KThread(new Runnable() {
            public void run() {
                KThread.yield();
                System.out.println("Listener thread started, about to listen...");
                int val = c.listen();
                System.out.println("Listener thread received word: " + val);
            }
        }).setName("Listener2");

        speaker.fork();
        listener.fork();
        speaker.join();
        listener.join();
    }

    /**
     * Test 3: 2 speakers, 2 listeners, intermixed
     */
    public static void commTest3() {
        System.out.println("\n-- commTest3: 2 speakers, 2 listeners (intermixed) --");
        final Communicator c = new Communicator();

        Runnable speakerRun = new Runnable() {
            public void run() {
                int speakVal = (int)(Math.random() * 500);
                System.out.println(KThread.currentThread().getName() + " speaking " + speakVal);
                c.speak(speakVal);
                System.out.println(KThread.currentThread().getName() + " done speaking " + speakVal);
            }
        };

        Runnable listenerRun = new Runnable() {
            public void run() {
                System.out.println(KThread.currentThread().getName() + " about to listen...");
                int val = c.listen();
                System.out.println(KThread.currentThread().getName() + " heard " + val);
            }
        };

        KThread speaker1 = new KThread(speakerRun).setName("Speaker1");
        KThread listener1 = new KThread(listenerRun).setName("Listener1");
        KThread speaker2 = new KThread(speakerRun).setName("Speaker2");
        KThread listener2 = new KThread(listenerRun).setName("Listener2");

        speaker1.fork();
        listener1.fork();
        speaker2.fork();
        listener2.fork();

        speaker1.join();
        listener1.join();
        speaker2.join();
        listener2.join();
    }

    /**
     * Test 4: 2 speakers first, then 2 listeners.
     */
    public static void commTest4() {
        System.out.println("\n-- commTest4: 2 speakers first, then 2 listeners --");
        final Communicator c = new Communicator();

        Runnable speakerRun = new Runnable() {
            public void run() {
                int speakVal = (int)(Math.random() * 500);
                System.out.println(KThread.currentThread().getName() + " speaking " + speakVal);
                c.speak(speakVal);
                System.out.println(KThread.currentThread().getName() + " done speaking " + speakVal);
            }
        };

        Runnable listenerRun = new Runnable() {
            public void run() {
                System.out.println(KThread.currentThread().getName() + " about to listen...");
                int val = c.listen();
                System.out.println(KThread.currentThread().getName() + " heard " + val);
            }
        };

        KThread speaker1 = new KThread(speakerRun).setName("Speaker1");
        KThread speaker2 = new KThread(speakerRun).setName("Speaker2");
        KThread listener1 = new KThread(listenerRun).setName("Listener1");
        KThread listener2 = new KThread(listenerRun).setName("Listener2");

        speaker1.fork();
        speaker2.fork();
        listener1.fork();
        listener2.fork();

        speaker1.join();
        speaker2.join();
        listener1.join();
        listener2.join();
    }

    /**
     * Test 5: Stress test with 100 speakers + 100 listeners intermixed.
     * We'll store references to join them all.
     */
    public static void commTest5() {
        System.out.println("\n-- commTest5: 100 speakers & 100 listeners stress test --");
        final Communicator c = new Communicator();
        KThread[] threads = new KThread[200];
        int index = 0;

        for (int i = 0; i < 100; i++) {
            final int speakVal = i;
            KThread speaker = new KThread(new Runnable() {
                public void run() {
                    System.out.println(KThread.currentThread().getName() + " speaking " + speakVal);
                    c.speak(speakVal);
                }
            }).setName("Speaker-" + i);

            KThread listener = new KThread(new Runnable() {
                public void run() {
                    int val = c.listen();
                    System.out.println(KThread.currentThread().getName() + " heard " + val);
                }
            }).setName("Listener-" + i);

            speaker.fork();
            listener.fork();
            threads[index++] = speaker;
            threads[index++] = listener;
        }

        // Join them all so no leftover threads remain
        for (int i = 0; i < 200; i++) {
            threads[i].join();
        }
    }

    /**
     * Test 6: Extra concurrency test from previous code (multiple calls).
     */
    public static void commTest6() {
        System.out.println("\n-- commTest6: Mixed concurrency test with random ordering --");
        final Communicator c = new Communicator();
        KThread[] threads = new KThread[10];
        int index = 0;

        for (int i = 0; i < 5; i++) {
            final int count = i;
            KThread spGroup = new KThread(new Runnable() {
                public void run() {
                    for (int j = 0; j < 2; j++) {
                        int val = (count * 10) + j;
                        System.out.println(KThread.currentThread().getName() + " speaking " + val);
                        c.speak(val);
                        KThread.yield();
                    }
                }
            }).setName("SpeakerGroup-" + i);

            KThread lsGroup = new KThread(new Runnable() {
                public void run() {
                    for (int j = 0; j < 2; j++) {
                        System.out.println(KThread.currentThread().getName() + " about to listen...");
                        int heard = c.listen();
                        System.out.println(KThread.currentThread().getName() + " heard " + heard);
                        KThread.yield();
                    }
                }
            }).setName("ListenerGroup-" + i);

            spGroup.fork();
            lsGroup.fork();
            threads[index++] = spGroup;
            threads[index++] = lsGroup;
        }

        for (int i = 0; i < 10; i++) {
            threads[i].join();
        }
    }




    // ------------------------------------------------------------------------
    // The snippet-based "CommSelfTester" code (do not delete any comments)
    // ------------------------------------------------------------------------

    /**
     * All-in-one selfTest() that calls both sets of tests:
     *  - commTest1..commTest6
     *  - CommSelfTester.selfTest1..5
     */
    public static void selfTest() {
        System.out.println("\n===== Communicator.selfTest() =====");

        commTest1();
        commTest2();
        commTest3();
        commTest4();
        commTest5();
        commTest6();

        // CommSelfTester.selfTest1();
        // CommSelfTester.selfTest2();
        // CommSelfTester.selfTest3();
        // CommSelfTester.selfTest4();
        // CommSelfTester.selfTest5();

        System.out.println("===== End of Communicator.selfTest() =====\n");
    }
}

// usage: 1. copy this file to Communicator.java. It should be outside of communicator class.
//        2. To use selfTest1, copy "CommSelfTester.selfTest1();" into selfTest() function in ThreadedKernel.java.
//        3. run it.
class CommSelfTester {

    // Debug flag (for Lib.debug output)
    private static final char dbgThread = 't';

    // These runnables call the shared listen and speak functions.
    private static Runnable listenRun = new Runnable() {
        public void run() {
            listenFunction();
        }
    };

    private static Runnable speakerRun = new Runnable() {
        public void run() {
            speakFunction();
        }
    };

    // Our shared Communicator and word counter.
    // (We reinitialize these in each test so that each test starts fresh.)
    private static Communicator myComm;
    private static int myWordCount;

    // This function will be called by the listenRun runnable.
    static void listenFunction() {
        Lib.debug(dbgThread, "Thread " + KThread.currentThread().getName() +
                  " is about to listen");
        int val = myComm.listen();
        Lib.debug(dbgThread, "Thread " + KThread.currentThread().getName() +
                  " got value " + val);
    }

    // This function will be called by the speakerRun runnable.
    static void speakFunction() {
        Lib.debug(dbgThread, "Thread " + KThread.currentThread().getName() +
                  " is about to speak");
        myComm.speak(myWordCount++);
        Lib.debug(dbgThread, "Thread " + KThread.currentThread().getName() +
                  " has spoken");
    }

    // Test 1: 1 listener then 1 speaker.
    public static void selfTest1() {
        // Reinitialize the communicator and counter.
        myComm = new Communicator();
        myWordCount = 0;
        
        KThread listener1 = new KThread(listenRun).setName("listener1");
        listener1.fork();
        KThread speaker1 = new KThread(speakerRun).setName("speaker1");
        speaker1.fork();
        // Wait for both threads to finish
        listener1.join();
        speaker1.join();
    }

    // Test 2: 1 speaker then 1 listener.
    public static void selfTest2() {
        myComm = new Communicator();
        myWordCount = 0;
        
        KThread speaker1 = new KThread(speakerRun).setName("speaker1");
        speaker1.fork();
        KThread listener1 = new KThread(listenRun).setName("listener1");
        listener1.fork();
        // Wait for both threads to finish
        speaker1.join();
        listener1.join();
    }

    // Test 3: 2 speakers and 2 listeners intermixed.
    public static void selfTest3() {
        myComm = new Communicator();
        myWordCount = 0;
        
        KThread speaker1 = new KThread(speakerRun).setName("speaker1");
        speaker1.fork();
        KThread listener1 = new KThread(listenRun).setName("listener1");
        listener1.fork();
        KThread speaker2 = new KThread(speakerRun).setName("speaker2");
        speaker2.fork();
        KThread listener2 = new KThread(listenRun).setName("listener2");
        listener2.fork();
        // Wait for all four threads to finish
        speaker1.join();
        listener1.join();
        speaker2.join();
        listener2.join();
    }

    // Test 4: 2 speakers then 2 listeners.
    public static void selfTest4() {
        myComm = new Communicator();
        myWordCount = 0;
        
        KThread speaker1 = new KThread(speakerRun).setName("speaker1");
        speaker1.fork();
        KThread speaker2 = new KThread(speakerRun).setName("speaker2");
        speaker2.fork();
        KThread listener1 = new KThread(listenRun).setName("listener1");
        listener1.fork();
        KThread listener2 = new KThread(listenRun).setName("listener2");
        listener2.fork();
        // Wait for all four threads to finish
        speaker1.join();
        speaker2.join();
        listener1.join();
        listener2.join();
    }

    // Test 5: Stress test with 100 speakers and 100 listeners intermixed.
    public static void selfTest5() {
        myComm = new Communicator();
        myWordCount = 0;
        
        for (int i = 0; i < 100; i++) {
            new KThread(speakerRun).setName("Speaker " + i).fork();
            new KThread(listenRun).setName("Listen " + i).fork();
        }
        // Let the threads run (using yields to allow them to complete).
        for (int i = 0; i < 1000; i++) {
            KThread.yield();
        }
    }
} // CommSelfTester class
