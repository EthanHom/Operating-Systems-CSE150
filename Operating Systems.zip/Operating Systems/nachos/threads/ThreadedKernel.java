package nachos.threads;

import nachos.machine.*;
// import nachos.threads.Communicator.CommSelfTester;
import nachos.threads.Communicator;
import nachos.threads.CommSelfTester;


/**
 * A multi-threaded OS kernel.
 */
public class ThreadedKernel extends Kernel {
	/**
	 * Allocate a new multi-threaded kernel.
	 */
	public ThreadedKernel() {
		super();
	}

	/**
	 * Initialize this kernel. Creates a scheduler, the first thread, and an
	 * alarm, and enables interrupts. Creates a file system if necessary.
	 */
	public void initialize(String[] args) {
		// set scheduler
		String schedulerName = Config.getString("ThreadedKernel.scheduler");
		scheduler = (Scheduler) Lib.constructObject(schedulerName);

		// set fileSystem
		String fileSystemName = Config.getString("ThreadedKernel.fileSystem");
		if (fileSystemName != null)
			fileSystem = (FileSystem) Lib.constructObject(fileSystemName);
		else if (Machine.stubFileSystem() != null)
			fileSystem = Machine.stubFileSystem();
		else
			fileSystem = null;

		// start threading
		new KThread(null);

		alarm = new Alarm();

		Machine.interrupt().enable();
	}

	/**
	 * Test this kernel. Test the <tt>KThread</tt>, <tt>Semaphore</tt>,
	 * <tt>SynchList</tt>, and <tt>ElevatorBank</tt> classes. Note that the
	 * autograder never calls this method, so it is safe to put additional tests
	 * here.
	 */
	public void selfTest() {
		KThread.selfTest();
		Semaphore.selfTest();
		SynchList.selfTest();
		Condition2.selfTest();
		Alarm.selfTest();
		Communicator.selfTest();
		System.out.println("===== Start of CommSelfTester.selfTest() =====\n");
		System.out.println("===== Start of CommSelfTester.selfTest1() =====\n");
		CommSelfTester.selfTest1();
		System.out.println("===== End of CommSelfTester.selfTest1() =====\n");
		System.out.println("===== Start of CommSelfTester.selfTest2() =====\n");
		CommSelfTester.selfTest2();
		System.out.println("===== End of CommSelfTester.selfTest2() =====\n");
		System.out.println("===== Start of CommSelfTester.selfTest3() =====\n");
		CommSelfTester.selfTest3();
		System.out.println("===== End of CommSelfTester.selfTest3() =====\n");
		System.out.println("===== Start of CommSelfTester.selfTest4() =====\n");
		CommSelfTester.selfTest4();
		System.out.println("===== End of CommSelfTester.selfTest4() =====\n");
		System.out.println("===== Start of CommSelfTester.selfTest5() =====\n");
		CommSelfTester.selfTest5();
		System.out.println("===== End of CommSelfTester.selfTest5() =====\n");
		System.out.println("===== End of CommSelfTester.selfTest() =====\n");
		System.out.println("===== Start of Boat.selfTest() =====\n");
		Boat.selfTest();
		System.out.println("===== End of Boat.selfTest() =====\n");
		if (Machine.bank() != null) {
			ElevatorBank.selfTest();
		}
	}

	/**
	 * A threaded kernel does not run user programs, so this method does
	 * nothing.
	 */
	public void run() {
	}

	/**
	 * Terminate this kernel. Never returns.
	 */
	public void terminate() {
		Machine.halt();
	}

	/** Globally accessible reference to the scheduler. */
	public static Scheduler scheduler = null;

	/** Globally accessible reference to the alarm. */
	public static Alarm alarm = null;

	/** Globally accessible reference to the file system. */
	public static FileSystem fileSystem = null;

	// dummy variables to make javac smarter
	private static RoundRobinScheduler dummy1 = null;

	private static PriorityScheduler dummy2 = null;

	private static LotteryScheduler dummy3 = null;

	private static Condition2 dummy4 = null;

	private static Communicator dummy5 = null;

	private static Rider dummy6 = null;

	private static ElevatorController dummy7 = null;
}
