// package nachos.threads;

// import java.util.Comparator;
// import java.util.PriorityQueue;
// import nachos.machine.*;

// /**
//  * Uses the hardware timer to provide preemption and to allow threads to
//  * sleep until a certain time without busy-waiting.
//  */
// public class Alarm {

//     /**
//      * A simple record storing a thread and the time at which it should be woken.
//      */
//     private static class Waiter {
//         long wakeTime;         // The time (in clock ticks) when this thread must be woken
//         KThread thread;        // The thread that is waiting

//         Waiter(long w, KThread t) {
//             wakeTime = w;
//             thread = t;
//         }
//     }

//     /**
//      * Compares Waiter objects by their wakeTime. The one with the lower wakeTime
//      * has higher priority (wakes sooner).
//      */
//     private static class WaiterComparator implements Comparator<Waiter> {
//         public int compare(Waiter w1, Waiter w2) {
//             if (w1.wakeTime < w2.wakeTime) {
//                 return -1;
//             } else if (w1.wakeTime > w2.wakeTime) {
//                 return 1;
//             } else {
//                 return 0;
//             }
//         }
//     }

//     /**
//      * A priority queue of waiting threads, sorted by the earliest wakeTime first.
//      * When the timer interrupt fires, we check the head of this queue to see if
//      * any threads are ready to be unblocked.
//      */
//     private PriorityQueue<Waiter> waitQueue;

//     /**
//      * Creates a new Alarm and sets the machine's timer interrupt handler to
//      * call our timerInterrupt() method periodically. There should only be
//      * one Alarm instance in Nachos.
//      */
//     public Alarm() {
//         waitQueue = new PriorityQueue<Waiter>(new WaiterComparator());

//         Machine.timer().setInterruptHandler(new Runnable() {
//             public void run() {
//                 timerInterrupt();
//             }
//         });
//     }

//     /**
//      * The timer interrupt handler, invoked automatically by Nachos approximately
//      * every 500 clock ticks. We:
//      *  1. Disable interrupts to safely modify the waitQueue.
//      *  2. Wake up all threads whose wakeTime <= currentTime.
//      *  3. Restore interrupts and yield to allow newly readied threads to run.
//      */
//     public void timerInterrupt() {
//         boolean intStatus = Machine.interrupt().disable();
//         long currentTime = Machine.timer().getTime();

//         // Wake any threads that have reached or passed their scheduled wakeTime
//         while (!waitQueue.isEmpty()) {
//             Waiter w = waitQueue.peek();  // Look at the earliest wakeTime
//             if (w.wakeTime <= currentTime) {
//                 waitQueue.poll();         // Remove from the queue
//                 w.thread.ready();         // Move that thread to the ready queue
//             } else {
//                 // Because the queue is sorted, if the earliest wakeTime is in the future,
//                 // no other threads can be woken yet.
//                 break;
//             }
//         }

//         Machine.interrupt().restore(intStatus);

//         // Yield the processor to let newly unblocked threads run immediately.
//         KThread.yield();
//     }

//     /**
//      * Put the current thread to sleep for at least x ticks, waking it up in the
//      * timer interrupt handler. This is done by calculating a future wakeTime,
//      * placing the current thread on the waitQueue, and then sleeping it.
//      *
//      * @param x minimum number of clock ticks to wait; if x <= 0, we return immediately.
//      */
//     public void waitUntil(long x) {
//         if (x <= 0) {
//             // No need to block if the requested wait time is zero or negative
//             return;
//         }

//         boolean intStatus = Machine.interrupt().disable();
//         long wakeTime = Machine.timer().getTime() + x;

//         // Create a record of the sleeping thread and its wakeTime
//         Waiter waiter = new Waiter(wakeTime, KThread.currentThread());
//         waitQueue.add(waiter);

//         // Put the current thread to sleep; we'll wake it in timerInterrupt()
//         KThread.sleep();

//         Machine.interrupt().restore(intStatus);
//     }

//     /**
//      * Simple test that checks how long the thread actually waits when calling waitUntil().
//      * We test three durations: 1,000; 10,000; and 100,000 ticks.
//      */
//     public static void alarmTest1() {
//         int durations[] = {1000, 10*1000, 100*1000};
//         long t0, t1;

//         for (int d : durations) {
//             t0 = Machine.timer().getTime();
//             ThreadedKernel.alarm.waitUntil(d);
//             t1 = Machine.timer().getTime();
//             System.out.println("alarmTest1: requested " + d + " ticks, actual wait = " + (t1 - t0) + " ticks");
//         }
//     }

//     /**
//      * Tests multiple threads waiting different amounts of time (500, 1000, 1500).
//      * Ensures that each thread sleeps and wakes independently based on its
//      * scheduled wakeTime.
//      */
//     public static void alarmTest2() {
//         final long[] intervals = {500, 1000, 1500};

//         for (final long waitTime : intervals) {
//             KThread thread = new KThread(new Runnable() {
//                 public void run() {
//                     long start = Machine.timer().getTime();
//                     System.out.println("Thread " + KThread.currentThread().getName() +
//                                        " sleeping for " + waitTime + " at time=" + start);
//                     ThreadedKernel.alarm.waitUntil(waitTime);
//                     long end = Machine.timer().getTime();
//                     System.out.println("Thread " + KThread.currentThread().getName() +
//                                        " woke up at time=" + end);
//                 }
//             });
//             thread.setName("AlarmTester-" + waitTime).fork();
//         }

//         // Yield to let the newly forked threads start running
//         KThread.yield();
//     }

//     /**
//      * selfTest() - Called from ThreadedKernel.selfTest().
//      * Runs our alarm test methods for demonstration.
//      */
//     public static void selfTest() {
//         System.out.println("\n===== Alarm.selfTest() =====");
//         alarmTest1();
//         alarmTest2();
//         System.out.println("===== End of Alarm.selfTest() =====\n");
//     }
// }
