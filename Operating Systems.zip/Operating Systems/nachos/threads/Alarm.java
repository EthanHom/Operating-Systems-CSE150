package nachos.threads;

import java.util.LinkedList;
import nachos.machine.*;

/**
 * Uses the hardware timer to provide preemption and to allow threads to
 * sleep until a certain time without busy-waiting.
 */
public class Alarm {

    /**
     * A simple record storing a thread and the time at which it should be woken.
     */
    private static class Waiter {
        long wakeTime;     // The time (in clock ticks) when this thread must be woken
        KThread thread;    // The thread that is waiting

        Waiter(long w, KThread t) {
            wakeTime = w;
            thread = t;
        }
    }

    /**
     * A linked list of waiting threads, kept in ascending order by their wakeTime.
     * The head of the list always has the earliest wakeTime.
     */
    private LinkedList<Waiter> waitList;

    /**
     * Creates a new Alarm and sets the machine's timer interrupt handler to
     * call our timerInterrupt() method periodically. There should only be
     * one Alarm instance in Nachos.
     */
    public Alarm() {
        waitList = new LinkedList<Waiter>();

        Machine.timer().setInterruptHandler(new Runnable() {
            public void run() {
                timerInterrupt();
            }
        });
    }

    /**
     * The timer interrupt handler, invoked automatically by Nachos approximately
     * every 500 clock ticks. We:
     *  1. Disable interrupts to safely modify the waitList.
     *  2. Wake up all threads whose wakeTime <= currentTime.
     *  3. Restore interrupts and yield to allow newly readied threads to run.
     */
    public void timerInterrupt() {
        boolean intStatus = Machine.interrupt().disable();
        long currentTime = Machine.timer().getTime();

        // Wake any threads that have reached or passed their scheduled wakeTime
        while (!waitList.isEmpty()) {
            Waiter earliest = waitList.getFirst(); 
            if (earliest.wakeTime <= currentTime) {
                waitList.removeFirst();  
                earliest.thread.ready(); 
            } else {
                // If the earliest wakeTime is still in the future,
                // no other threads can be woken yet.
                break;
            }
        }

        Machine.interrupt().restore(intStatus);

        // Yield the processor to let newly unblocked threads run immediately.
        KThread.yield();
    }

    /**
     * Put the current thread to sleep for at least x ticks, waking it up in the
     * timer interrupt handler. This is done by calculating a future wakeTime,
     * placing the current thread in waitList (sorted), and then sleeping it.
     *
     * @param x minimum number of clock ticks to wait; if x <= 0, we return immediately.
     */
    public void waitUntil(long x) {
        if (x <= 0) {
            // No need to block if the requested wait time is zero or negative
            return;
        }

        boolean intStatus = Machine.interrupt().disable();
        long wakeTime = Machine.timer().getTime() + x;

        // Create a record of the sleeping thread and its wakeTime
        Waiter waiter = new Waiter(wakeTime, KThread.currentThread());

        // Insert this waiter into the list in ascending order
        insertWaiterSorted(waiter);

        // Put the current thread to sleep; we'll wake it in timerInterrupt()
        KThread.sleep();

        Machine.interrupt().restore(intStatus);
    }

    /**
     * Helper method to insert a Waiter into waitList in ascending wakeTime order.
     */
    private void insertWaiterSorted(Waiter newWaiter) {
        int i = 0;
        while (i < waitList.size()) {
            if (newWaiter.wakeTime < waitList.get(i).wakeTime) {
                break;
            }
            i++;
        }
        waitList.add(i, newWaiter);
    }

    /* ------------------------------------------------------------------------
     *  Below are our eight test methods, plus selfTest() that calls them all.
     * ------------------------------------------------------------------------ */

    /**
     * alarmTest1():
     * Simple test that checks how long the thread actually waits when calling waitUntil().
     * We test three durations: 1,000; 10,000; and 100,000 ticks.
     */
    public static void alarmTest1() {
        int durations[] = {1000, 10*1000, 100*1000};
        long t0, t1;

        System.out.println("-- alarmTest1: Basic intervals (1k, 10k, 100k) --");
        for (int d : durations) {
            t0 = Machine.timer().getTime();
            ThreadedKernel.alarm.waitUntil(d);
            t1 = Machine.timer().getTime();
            System.out.println("alarmTest1: requested " + d 
                               + " ticks, actual wait = " + (t1 - t0) + " ticks");
        }
    }

    /**
     * alarmTest2():
     * Tests multiple threads waiting different amounts of time (500, 1000, 1500).
     * Ensures that each thread sleeps and wakes independently based on its
     * scheduled wakeTime.
     */
    public static void alarmTest2() {
        System.out.println("\n-- alarmTest2: Multiple threads with fixed intervals --");
        final long[] intervals = {500, 1000, 1500};

        for (final long waitTime : intervals) {
            KThread thread = new KThread(new Runnable() {
                public void run() {
                    long start = Machine.timer().getTime();
                    System.out.println("Thread " + KThread.currentThread().getName() +
                                       " sleeping for " + waitTime + " at time=" + start);
                    ThreadedKernel.alarm.waitUntil(waitTime);
                    long end = Machine.timer().getTime();
                    System.out.println("Thread " + KThread.currentThread().getName() +
                                       " woke up at time=" + end);
                }
            });
            thread.setName("AlarmTester-" + waitTime).fork();
        }
        KThread.yield();
    }

    /**
     * alarmTest3():
     * Tests the behavior when waitUntil(0) or a negative value is used.
     * These calls should return immediately (no blocking).
     */
    public static void alarmTest3() {
        System.out.println("\n-- alarmTest3: Testing zero or negative wait times --");
        long t0, t1;

        System.out.println("Current time is " + Machine.timer().getTime());
        System.out.println("Calling waitUntil(0)...");
        t0 = Machine.timer().getTime();
        ThreadedKernel.alarm.waitUntil(0);
        t1 = Machine.timer().getTime();
        System.out.println("Waited " + (t1 - t0) + " ticks (should be very small, ideally 0).");

        System.out.println("Calling waitUntil(-100)...");
        t0 = Machine.timer().getTime();
        ThreadedKernel.alarm.waitUntil(-100);
        t1 = Machine.timer().getTime();
        System.out.println("Waited " + (t1 - t0) + " ticks (should be very small, ideally 0).");
    }

    /**
     * alarmTest4():
     * A concurrency test where multiple threads each call waitUntil()
     * multiple times with random intervals, to test interleavings.
     */
    public static void alarmTest4() {
        System.out.println("\n-- alarmTest4: Concurrency test with random intervals --");
        final int threadCount = 3;

        for (int i = 0; i < threadCount; i++) {
            KThread t = new KThread(new Runnable() {
                public void run() {
                    for (int j = 0; j < 3; j++) {
                        long randomWait = 200 + (long)(Math.random() * 300); // between 200 and 500
                        long start = Machine.timer().getTime();
                        System.out.println(KThread.currentThread().getName() 
                                           + " iteration #" + j 
                                           + ", sleeping for " + randomWait 
                                           + " at time=" + start);

                        ThreadedKernel.alarm.waitUntil(randomWait);

                        long end = Machine.timer().getTime();
                        System.out.println(KThread.currentThread().getName() 
                                           + " iteration #" + j 
                                           + " woke at time=" + end);
                        KThread.yield();
                    }
                }
            });
            t.setName("AlarmThread-" + i).fork();
        }
        KThread.yield();
    }

    /**
     * alarmTest5():
     * Repeated waits in the same thread, each time with different intervals.
     */
    public static void alarmTest5() {
        System.out.println("\n-- alarmTest5: Repeated waits in the same thread --");

        KThread thread = new KThread(new Runnable() {
            public void run() {
                long intervals[] = {200, 400, 100, 800};
                for (int i = 0; i < intervals.length; i++) {
                    long start = Machine.timer().getTime();
                    long waitTime = intervals[i];
                    System.out.println("Thread " + KThread.currentThread().getName() + 
                                       " calling waitUntil(" + waitTime + ") at time=" + start);

                    ThreadedKernel.alarm.waitUntil(waitTime);

                    long end = Machine.timer().getTime();
                    System.out.println("Thread " + KThread.currentThread().getName() + 
                                       " woke at time=" + end + 
                                       " (slept ~" + (end - start) + " ticks).");
                    KThread.yield();
                }
            }
        });
        thread.setName("AlarmTest5Thread").fork();
        thread.join();
    }

    /**
     * alarmTest6():
     * Large concurrency test: spawns many threads with random intervals
     * to see if the alarm can handle a heavier load without issues.
     */
    public static void alarmTest6() {
        System.out.println("\n-- alarmTest6: Large concurrency stress test --");
        final int threadCount = 10; // or more to stress test

        for (int i = 0; i < threadCount; i++) {
            KThread t = new KThread(new Runnable() {
                public void run() {
                    long wait = 500 + (long)(Math.random() * 2000); // 500 to 2500
                    long start = Machine.timer().getTime();
                    System.out.println(KThread.currentThread().getName() + 
                                       " sleeping for " + wait + 
                                       " ticks at time=" + start);

                    ThreadedKernel.alarm.waitUntil(wait);

                    long end = Machine.timer().getTime();
                    System.out.println(KThread.currentThread().getName() + 
                                       " woke up at time=" + end +
                                       " (slept ~" + (end - start) + " ticks).");
                }
            });
            t.setName("AlarmStress-" + i).fork();
        }
        KThread.yield();
    }

    /**
     * alarmTest7():
     * Very large intervals: ensures we handle long waits without overflow or immediate wakeup.
     */
    public static void alarmTest7() {
        System.out.println("\n-- alarmTest7: Very large wait times --");

        KThread longWait = new KThread(new Runnable() {
            public void run() {
                // long bigInterval = 200000; // 200k ticks, can adjust as desired
                long bigInterval = 10000; // 200k ticks, can adjust as desired
                long start = Machine.timer().getTime();
                System.out.println("Thread " + KThread.currentThread().getName() + 
                                   " waiting for " + bigInterval + " ticks at time=" + start);

                ThreadedKernel.alarm.waitUntil(bigInterval);

                long end = Machine.timer().getTime();
                System.out.println("Thread " + KThread.currentThread().getName() + 
                                   " woke up at time=" + end +
                                   " (slept ~" + (end - start) + " ticks).");
            }
        });
        longWait.setName("MaxWaitThread").fork();

        KThread.yield();
    }

    /**
     * alarmTest8():
     * Interleaved waits and non-wait "work" in multiple threads.
     * Some calls to waitUntil(), some just do quick loops or yields,
     * to ensure the Alarm doesn't interfere with normal scheduling.
     */
    public static void alarmTest8() {
        System.out.println("\n-- alarmTest8: Interleaved waits and work --");

        final int threadCount = 4;
        for (int i = 0; i < threadCount; i++) {
            KThread t = new KThread(new Runnable() {
                public void run() {
                    for (int j = 0; j < 3; j++) {
                        if (Math.random() < 0.5) {
                            long waitTime = 200 + (int)(Math.random() * 800);
                            System.out.println(KThread.currentThread().getName() + 
                                " iteration #" + j + ", waitUntil(" + waitTime + ")");
                            ThreadedKernel.alarm.waitUntil(waitTime);
                        } else {
                            System.out.println(KThread.currentThread().getName() + 
                                " iteration #" + j + ", doing immediate work (no wait).");
                            // Simulate some quick "work" with a few yields
                            for (int k = 0; k < 5; k++) {
                                KThread.yield();
                            }
                        }
                    }
                }
            });
            t.setName("MixThread-" + i).fork();
        }
        KThread.yield();
    }

    /**
     * selfTest() - Called from ThreadedKernel.selfTest().
     * Runs our alarm test methods for demonstration.
     */
    public static void selfTest() {
        System.out.println("\n===== Alarm.selfTest() =====");
        alarmTest1(); // Basic intervals (1k, 10k, 100k)
        alarmTest2(); // Multiple threads, fixed intervals
        alarmTest3(); // Zero/negative intervals
        alarmTest4(); // Concurrency with random intervals
        alarmTest5(); // Repeated waits in the same thread
        alarmTest6(); // Large concurrency/stress test
        alarmTest7(); // Very large intervals
        alarmTest8(); // Interleaved waits vs. "work"
        System.out.println("===== End of Alarm.selfTest() =====\n");
    }
}
