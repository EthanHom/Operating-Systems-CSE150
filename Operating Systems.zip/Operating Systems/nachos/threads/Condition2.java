package nachos.threads;

import nachos.machine.*;
import java.util.LinkedList;

/**
 * An implementation of condition variables that disables interrupt()s
 * for synchronization (instead of using semaphores).
 *
 * @see nachos.threads.Condition
 */
public class Condition2 {
    /**
     * Allocate a new condition variable.
     *
     * @param conditionLock the lock associated with this condition variable.
     * The current thread must hold this lock whenever it uses <tt>sleep()</tt>,
     * <tt>wake()</tt>, or <tt>wakeAll()</tt>.
     */
    public Condition2(Lock conditionLock) {
        this.conditionLock = conditionLock;
        this.waitQueue = new LinkedList<KThread>();
    }

    /**
     * Atomically release the associated lock and go to sleep on this condition
     * variable until another thread wakes it using <tt>wake()</tt>. The current
     * thread must hold the associated lock. The thread will automatically
     * reacquire the lock before <tt>sleep()</tt> returns.
     */
    public void sleep() {
        Lib.assertTrue(conditionLock.isHeldByCurrentThread());

        boolean intStatus = Machine.interrupt().disable();

        // Add current thread to wait queue
        waitQueue.add(KThread.currentThread());

        // Release lock, block
        conditionLock.release();
        KThread.sleep();

        // When woken, reacquire lock
        conditionLock.acquire();

        Machine.interrupt().restore(intStatus);
    }

    /**
     * Wake up at most one thread sleeping on this condition variable. The
     * current thread must hold the associated lock.
     */
    public void wake() {
        Lib.assertTrue(conditionLock.isHeldByCurrentThread());

        boolean intStatus = Machine.interrupt().disable();
        if (!waitQueue.isEmpty()) {
            KThread thread = waitQueue.removeFirst();
            if (thread != null) {
                thread.ready();
            }
        }
        Machine.interrupt().restore(intStatus);
    }

    /**
     * Wake up all threads sleeping on this condition variable. The current
     * thread must hold the associated lock.
     */
    public void wakeAll() {
        Lib.assertTrue(conditionLock.isHeldByCurrentThread());

        while (!waitQueue.isEmpty()) {
            wake();
        }
    }

    /**
     * Atomically release the associated lock and go to sleep on this condition
     * variable until either (1) another thread wakes it using <tt>wake()</tt>,
     * or (2) the specified <i>timeout</i> elapses. The current thread must
     * hold the associated lock. The thread will automatically reacquire the
     * lock before <tt>sleepFor()</tt> returns.
     *
     * <p>
     * This simple implementation uses a while loop checking <code>Machine.timer().getTime()</code>
     * and can result in partial busy-waiting. A more robust approach might integrate
     * with Alarm, but for many use cases, this is sufficient.
     * </p>
     *
     * @param timeout the maximum number of clock ticks to wait.
     */
    public void sleepFor(long timeout) {
        Lib.assertTrue(conditionLock.isHeldByCurrentThread());

        if (timeout <= 0) {
            return; // no need to block
        }

        long wakeTime = Machine.timer().getTime() + timeout;
        boolean intStatus = Machine.interrupt().disable();

        waitQueue.add(KThread.currentThread());
        conditionLock.release();

        while (Machine.timer().getTime() < wakeTime &&
               waitQueue.contains(KThread.currentThread())) {
            KThread.sleep();
            if (Machine.timer().getTime() < wakeTime &&
                waitQueue.contains(KThread.currentThread())) {
                KThread.yield();
            }
        }

        waitQueue.remove(KThread.currentThread());
        conditionLock.acquire();
        Machine.interrupt().restore(intStatus);
    }

    // ------------------------------------------------------------------------
    // Internal Fields
    // ------------------------------------------------------------------------
    private Lock conditionLock;
    private LinkedList<KThread> waitQueue;


    // ------------------------------------------------------------------------
    //                   TEST CODE FOR Condition2
    // ------------------------------------------------------------------------

    /**
     * Example of the "interlock" pattern (ping-pong) from your snippet,
     * but with 10 iterations for each thread to strictly alternate.
     */
    private static class InterlockTest {
        private static Lock lock;
        private static Condition2 cv;

        private static class Interlocker implements Runnable {
            public void run() {
                lock.acquire();
                for (int i = 0; i < 10; i++) {
                    System.out.println(KThread.currentThread().getName());
                    cv.wake();   // signal
                    cv.sleep();  // wait
                }
                lock.release();
            }
        }

        public InterlockTest() {
            System.out.println("\n-- Condition2 InterlockTest (10 iterations) --");
            lock = new Lock();
            cv = new Condition2(lock);

            KThread ping = new KThread(new Interlocker()).setName("ping");
            KThread pong = new KThread(new Interlocker()).setName("pong");

            ping.fork();
            pong.fork();

            // If we have implemented join, let's wait on ping so it can finish.
            // If we also joined on pong, we could block forever if pong remains asleep.
            ping.join();
            // Alternatively, you could do the yield loop hack:
            // for (int i = 0; i < 50; i++) { KThread.yield(); }
        }
    }

    /**
     * Provided test program (producer/consumer) from your snippet: cvTest5().
     */
    public static void cvTest5() {
        System.out.println("\n-- Condition2 cvTest5 (Producer/Consumer) --");
        final Lock lock = new Lock();
        final Condition2 empty = new Condition2(lock);
        final LinkedList<Integer> list = new LinkedList<Integer>();

        KThread consumer = new KThread(new Runnable() {
            public void run() {
                lock.acquire();
                while (list.isEmpty()) {
                    empty.sleep();
                }
                Lib.assertTrue(list.size() == 5, "List should have 5 values.");
                while (!list.isEmpty()) {
                    // yield for scheduling fun
                    KThread.yield();
                    System.out.println("Removed " + list.removeFirst());
                }
                lock.release();
            }
        }).setName("Consumer");

        KThread producer = new KThread(new Runnable() {
            public void run() {
                lock.acquire();
                for (int i = 0; i < 5; i++) {
                    list.add(i);
                    System.out.println("Added " + i);
                    KThread.yield();
                }
                empty.wake();
                lock.release();
            }
        }).setName("Producer");

        consumer.fork();
        producer.fork();

        consumer.join();
        producer.join();
    }


    /**
     * A single-thread test: main thread wakes the sleeper.
     */
    private static class SingleThreadTest {
        private static Lock lock;
        private static Condition2 cv;

        private static class Sleeper implements Runnable {
            public void run() {
                lock.acquire();
                System.out.println("Sleeper thread going to sleep...");
                cv.sleep();
                System.out.println("Sleeper thread woke up after wake()");
                lock.release();
            }
        }

        public SingleThreadTest() {
            System.out.println("\n-- Condition2 SingleThreadTest --");
            lock = new Lock();
            cv = new Condition2(lock);

            KThread thread = new KThread(new Sleeper()).setName("SleeperThread");
            thread.fork();

            KThread.yield();

            // main thread calls wake
            lock.acquire();
            System.out.println("Main thread calling wake()");
            cv.wake();
            lock.release();

            thread.join();
        }
    }

    /**
     * Multiple threads all sleeping, then main does wake(), then wakeAll().
     */
    private static class MultipleThreadsTest {
        private static Lock lock;
        private static Condition2 cv;

        private static class Sleeper implements Runnable {
            public void run() {
                lock.acquire();
                System.out.println(KThread.currentThread().getName() + " going to sleep...");
                cv.sleep();
                System.out.println(KThread.currentThread().getName() + " woke up!");
                lock.release();
            }
        }

        public MultipleThreadsTest() {
            System.out.println("\n-- Condition2 MultipleThreadsTest --");
            lock = new Lock();
            cv = new Condition2(lock);

            KThread t1 = new KThread(new Sleeper()).setName("thread1");
            KThread t2 = new KThread(new Sleeper()).setName("thread2");
            KThread t3 = new KThread(new Sleeper()).setName("thread3");

            t1.fork();
            t2.fork();
            t3.fork();

            KThread.yield();

            lock.acquire();
            System.out.println("Main thread calling wake() => Should wake exactly 1 sleeper");
            cv.wake();
            lock.release();

            KThread.yield();

            lock.acquire();
            System.out.println("Main thread calling wakeAll() => Should wake remaining sleepers");
            cv.wakeAll();
            lock.release();

            t1.join();
            t2.join();
            t3.join();
        }
    }

    /**
     * Calls wake() when no threads are sleeping. Should do nothing.
     */
    private static class NoSleepingThreadsTest {
        public NoSleepingThreadsTest() {
            System.out.println("\n-- Condition2 NoSleepingThreadsTest --");
            Lock lock = new Lock();
            Condition2 cv = new Condition2(lock);

            lock.acquire();
            System.out.println("Calling wake() with no sleepers...");
            cv.wake();
            System.out.println("No error => success!");
            lock.release();
        }
    }

    /**
     * Demonstration of sleepFor(...) with different durations.
     */
    private static class SleepForTest {
        private static Lock lock;
        private static Condition2 cv;

        private static class SleepRunner implements Runnable {
            private long sleepTime;
            public SleepRunner(long t) { this.sleepTime = t; }

            public void run() {
                lock.acquire();
                long start = Machine.timer().getTime();
                System.out.println(KThread.currentThread().getName() +
                    " sleeping for " + sleepTime + " ticks at time=" + start);
                cv.sleepFor(sleepTime);
                long end = Machine.timer().getTime();
                System.out.println(KThread.currentThread().getName() +
                    " woke up at time=" + end +
                    " (slept ~" + (end - start) + " ticks).");
                lock.release();
            }
        }

        public SleepForTest() {
            System.out.println("\n-- Condition2 SleepForTest --");
            lock = new Lock();
            cv = new Condition2(lock);

            long[] intervals = {500, 1000, 1500};
            for (long interval : intervals) {
                KThread t = new KThread(new SleepRunner(interval));
                t.setName("SleepForThread-" + interval).fork();
            }
            KThread.yield();
        }
    }

    /**
     * Combine all Condition2 test scenarios into one call. 
     * You can invoke Condition2.selfTest() from ThreadedKernel.selfTest().
     */
    public static void selfTest() {
        System.out.println("\n===== Condition2.selfTest() =====");

        new InterlockTest();            // Ping/pong for 10 iterations
        new SingleThreadTest();         // Single sleeper, main wakes
        new MultipleThreadsTest();      // 3 sleepers, partial wake, then wakeAll
        new NoSleepingThreadsTest();    // wake() with no sleepers
        cvTest5();                      // Producer/Consumer snippet
        new SleepForTest();             // Demonstrate sleepFor

        System.out.println("===== End of Condition2.selfTest() =====\n");
    }
}
